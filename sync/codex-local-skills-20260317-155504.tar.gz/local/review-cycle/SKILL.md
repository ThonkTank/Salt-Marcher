---
name: review-cycle
description: Orchestrate iterative post-implementation review/fix cycles with review subagents until the implementation reaches a clean stopping point with no actionable findings. Use when Codex has already implemented a change and should repeatedly run selected review skills, fix issues, and re-review while preserving the original user goal and intended behavior while allowing justified structural fixes beyond the initial implementation scope.
---

Preserve the original user request as a hard invariant for the entire cycle.

## Invariants

Before starting the cycle, restate and lock these three items from the current task context:
- the user goal
- the intended behavior to preserve
- the initial review scope

Treat the user goal and intended behavior as immutable for the rest of the cycle unless the user explicitly changes them.

Treat the initial review scope as the default starting boundary, not a hard cap. The cycle may expand beyond it when that is necessary to resolve a concrete review finding cleanly.

Never:
- remove the requested behavior just because a reviewer dislikes it
- introduce new product requirements or broaden the target UX beyond the original ask
- narrow the implementation below the original ask
- change the target UX or behavior unless the current implementation is objectively broken or contradictory
- revert unrelated user changes

## Scope resolution

If the user provided a file or directory scope, use it as the primary review scope.

Otherwise review the current uncommitted changes as the primary review scope.

If there is no reviewable scope, stop and report that there is nothing to review.

When a valid finding cannot be fixed cleanly inside the primary review scope, expand the fix scope only as far as needed:
- first to the full touched files
- then to directly coupled neighboring files or new helper files
- then to the affected module or tightly related modules
- only in rare cases to a broader project-wide refactor, and only when the reviewer has identified a concrete structural problem that cannot be resolved proportionally within a smaller boundary

Scope expansion is for technical and structural remediation only. It must not be used to introduce new user-facing capabilities.

## Reviewer selection

If the user explicitly names review skills, use exactly those roles.

If no roles were named, auto-select from this implementation-focused set only:
- `review-architecture`
- `review-smells`
- `review-security`
- `review-performance`
- `review-elegance`
- `review-simplicity`
- `review-conventions`
- `review-structure`
- `review-onboarding`

Never auto-add:
- `review-design`
- `review-accessibility`
- `review-ux`
- `review-ui`

Do not include `research-review` unless the user explicitly requests it.

Validate that each requested skill exists before starting the cycle.

## Review workflow

Choose the orchestration mode from the reviewer count:
- if there are 3 or fewer selected reviewers, use the synchronous round-based workflow below
- if there are more than 3 selected reviewers, use the asynchronous continuous workflow below

### Synchronous mode for 3 or fewer reviewers

For each round:
1. Spawn one subagent per selected review skill in parallel.
2. Give every reviewer the same briefing:
   - Use the exact reviewer prompt skeleton from `Implementation notes` below. It is the single canonical briefing structure.
   - Keep each section short and role-specific. Do not paste the whole orchestration policy into reviewer prompts.
   - Do not include meta-cycle instructions in reviewer briefings. Reviewer prompts must not mention:
     - total rounds
     - deduplication
     - invariant filtering
     - prioritization across reviewers
     - fixing findings
     - rerunning review rounds
     - final cycle success/failure
   - Do not ask a reviewer to speak for other roles or for the overall cycle.
   - Give each reviewer only the minimum context needed for that role. Prefer the same `Scope`, `User Goal`, and `Preserve` text across all reviewers, and vary only the `Role`.
   - Do not use the briefing to restate the review method, checklist, heuristics, or standards for the role. Those belong to the selected review skill and must not be paraphrased or replaced by the coordinator prompt.
   - Require the reviewer to treat the requested behavior as intentional unless it is concretely broken, unsafe, or contradictory.
   - Require the reviewer to return only actionable findings within the assigned role. If a potential issue falls outside that role, the reviewer must omit it.
   - Allow the reviewer to name structural issues beyond the initial scope when they are directly relevant to a clean fix, and require them to keep the proposed scope expansion proportional.
3. Wait for all reviewers to finish.
4. Collect their findings and discard responses that amount to no actionable findings.
5. Deduplicate overlapping findings by underlying issue, keeping the strongest wording.
6. Filter out findings that would violate the locked goal or intended behavior, are purely preference-driven, or would require a disproportionate scope expansion relative to the problem they solve.
7. If no actionable findings remain, stop the cycle and report success.
8. Prioritize the remaining findings by severity, user impact, regression risk, blast radius, and the minimum scope expansion needed to fix them well.
9. For each finding, choose the smallest fix scope that actually resolves the underlying issue instead of papering over it.
10. Fix the actionable findings directly.
11. Run appropriate verification for the implementation after the fixes when feasible.
12. Start the next round against the updated implementation.

Continue until a full round returns no actionable findings. Do not impose a fixed round cap.

### Asynchronous mode for more than 3 reviewers

1. Spawn one subagent per selected review skill in parallel.
2. Give every reviewer the same briefing rules from this skill, without telling them about rounds as a control structure.
3. Maintain coordinator state continuously:
   - running reviewers
   - open actionable findings
   - findings already fixed, rejected, or superseded
   - the code state that each reviewer result applies to
4. As soon as a reviewer returns:
   - collect its findings immediately
   - discard responses that amount to no actionable findings
   - deduplicate against all already known findings, not only the latest arrivals
   - filter out findings that would violate the locked goal or intended behavior, are purely preference-driven, or would require a disproportionate scope expansion relative to the problem they solve
   - once that review result has been processed, decide whether that reviewer should be launched again against the newer code state
5. As soon as actionable findings are available, prioritize them immediately by severity, user impact, regression risk, blast radius, and the minimum scope expansion needed to fix them well.
6. Fix actionable findings in small batches instead of waiting for every reviewer to finish.
7. After each fix batch:
   - run appropriate verification for that batch when feasible
   - mark older reviewer results and findings as stale if they were produced against an earlier code state
8. Before acting on a finding from an older reviewer result, confirm that the finding is still current on the latest code state instead of applying stale advice blindly.
9. Do not interrupt or abort a running reviewer just because later fixes changed the code. Let the running review finish, then filter any stale findings in the coordinator.
10. After a reviewer finishes and its result has been fully processed, restart that reviewer against the latest code state if more review work is still warranted.
11. Continue this loop until quiescence is reached.

Quiescence means all of the following are true at the same time:
- there are no open actionable findings
- no fixes are currently being applied
- no reviewers are still running
- no not-yet-processed reviewer results remain
- no reviewer needs to be relaunched for another pass on the latest code state

A `No actionable findings.` result only counts for the exact code state the reviewer saw. Any later fix must not abort that finished review retroactively, but it does mean the coordinator should schedule a fresh pass later if that reviewer still needs to inspect the newer code.

## Conflict handling

When reviewers disagree:
- prefer the narrower change that resolves a concrete risk without altering the original goal or behavior
- reject suggestions that mainly reflect reviewer preference rather than a concrete defect, drift, or structural risk
- reject proposals that remove or redesign the requested interaction unless the implementation is actually broken
- if multiple fixes would work, choose the smallest scope expansion that fully resolves the issue

Ask the user only when there is a real blocker that cannot be resolved from repo context, such as a genuine ambiguity in the requested behavior or reviewer demands that are both plausible and mutually incompatible.

## Expected updates during the cycle

In synchronous mode, after each round, provide a compact progress update containing:
- roles run
- raw finding count
- actionable finding count after filtering
- what was fixed
- whether the scope was expanded and why
- confirmation that the original goal and behavior were preserved
- whether another round is starting

In asynchronous mode, after each meaningful fix batch or status change, provide a compact progress update containing:
- roles run or currently running
- raw finding count seen so far
- open actionable finding count
- what was fixed in the latest batch
- whether the scope was expanded and why
- how many stale findings or results were discarded
- which reviewers finished and which were requeued
- whether quiescence has been reached yet
- confirmation that the original goal and behavior were preserved

At the end, report:
- total rounds executed in synchronous mode, or that asynchronous mode was used
- roles used
- whether the cycle ended cleanly or stopped on a real blocker
- any larger reviewer suggestions that were intentionally rejected because they would have changed the original goal or intended behavior
- any meaningful scope expansions that were taken during the cycle

## Implementation notes

Use parallel reviewer subagents when possible.

When writing reviewer prompts, prefer this exact skeleton and fill in only the bracketed values:

```markdown
Role: [one review role]

Scope:
[exact files or diff scope]

User Goal:
[one short sentence]

Preserve:
[one short sentence]

Constraints:
- Review this scope first, but you may identify directly relevant structural issues in adjacent code when they matter for a clean fix.
- Do not propose new product scope, scope reduction, or behavior reversal.
- Treat the requested behavior as intentional unless it is concretely broken, unsafe, or contradictory.
- Use the methodology and criteria from your assigned review skill; this briefing only assigns scope and invariants.
- Return only findings that fall inside your assigned role.
- If you propose a fix beyond the initial scope, name the smallest scope expansion that would solve it cleanly.

Output Format:
- If you find issues, return only actionable findings ordered by severity with file/line references.
- If you find no actionable issues, say exactly: `No actionable findings.`
```

When fixing findings, preserve normal repo rules:
- do not revert unrelated user changes
- do not add tests unless the user asked for them
- keep the requested implementation intact while improving correctness, maintainability, performance, security, consistency, or architecture
- prefer structural fixes that remove the root cause over local patches that knowingly preserve drift
- in asynchronous mode, apply fixes serially in coordinator-controlled batches even though findings arrive asynchronously
- in asynchronous mode, never cancel a running review for staleness alone; staleness is handled only after the result returns

If a reviewer identifies a genuine structural hotspot such as a god class, oversized file, or module boundary problem in code already implicated by the task, treat that as in scope for the cycle as long as the fix preserves the requested behavior and remains proportional.

If a reviewer keeps re-raising a suggestion that conflicts with the locked goal or intended behavior, continue rejecting it and note that it is out of scope instead of oscillating the implementation.
