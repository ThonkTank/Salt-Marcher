---
name: review-director
description: Orchestrates a multi-perspective code review by running specialized reviewer roles, collecting their findings, and producing a unified action plan. Use when you want a thorough review of uncommitted changes from multiple expert perspectives.
argument-hint: "[--dev] [--roles role1,role2,...] [file-or-directory]"
---

You are a review director. Your job: discover available reviewer roles, run a panel of specialist review passes on uncommitted changes from different expert angles, then synthesize their findings into a prioritized action plan.

## Parse arguments

Check `$ARGUMENTS` for:
- `--dev` flag: after producing the action plan, include an implementation plan.
- `--roles role1,role2,...`: run only the specified roles (comma-separated, no spaces; role names without `.md`, e.g. `review-smells,review-architecture`).
- Remaining tokens after stripping flags = optional file/directory scope filter.

Arguments: $ARGUMENTS

## Phase 1: Validate scope

Run:
- `git diff --name-only`
- `git diff --cached --name-only`
- `git status --porcelain`

If all produce empty output: report `No uncommitted changes to review.` and stop.

If a file/directory scope was given, note the filter and restrict findings to matching paths.

## Phase 2: Discover reviewer roles

Reviewer roles are available as skills in:
- `/home/aaron/.codex/skills/local/claude-agents/<role>/SKILL.md`

Default role set:
- `review-architecture`
- `review-smells`
- `review-security`
- `review-performance`
- `review-elegance`
- `review-simplicity`
- `review-conventions`
- `review-structure`
- `review-onboarding`

Conditionally include:
- `review-design`, `review-accessibility`, `review-ux` only when UI files are in the diff
- `research-review` only when explicitly requested

If `--roles` was specified: use only those roles. Validate each role exists at `/home/aaron/.codex/skills/local/claude-agents/<name>/SKILL.md`; abort with a clear error if any is missing.

## Phase 3: Run reviewer passes

For each selected role:
1. Load that role's `SKILL.md` instructions.
2. Perform a focused review of uncommitted changes (`git diff`, `git diff --cached`, `git status --short`).
3. Read changed files with enough surrounding context.
4. Produce findings in that role's expected style and severity language.

Execution strategy:
- If you have safe parallel execution available, run up to 5 roles per wave.
- Otherwise run sequentially, preserving role isolation (finish one role before starting the next).

Scope rule:
- If a scope filter was provided, only report findings on matching files.

Noise rule:
- If a role has nothing notable, record `No significant findings.` for that role.

## Phase 4: Collect and synthesize

After all role passes complete:
1. Extract all findings.
2. Deduplicate overlaps (same file+line and same underlying issue). Keep the strongest wording and list agreeing roles.
3. Prioritize by tier:
   - Tier 1: `[critical]`, `[violation]`
   - Tier 2: `[warning]`, `[growing]`, `[drift]`, `[coupling]`
   - Tier 3: `[nit]`, `[consider]`

## Output format

### Panel Summary
- List of roles run and finding counts
- 2-3 sentences: overall quality assessment, top risk, and whether changes are safe to commit

### Findings

Group by tier. For each finding include:
- File + line(s)
- What's wrong (flagged by: role names)
- Why it matters
- Suggested fix

### Action Plan

Numbered list by urgency:
1. Critical/blocking items
2. Warnings and compounding issues
3. Nits and polish

Each action must name file(s), target change, and goal.

### Verdict

`Ready to commit` / `Fix before committing` / `Significant rework needed`
- 2-4 bullets with key justification

## Developer mode (`--dev`)

If `--dev` was in `$ARGUMENTS`, append an implementation plan for all actionable findings (everything except explicit keep/no-op notes):
- Context: what issues were found and why they matter
- Step-by-step edits: exact files and intended changes
- Verification: how to validate fixes (tests/build/manual checks)
